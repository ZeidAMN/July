﻿window.blazorInterop = {
    callFromBlazor: function () {
        alert('JavaScript function called from Blazor!');
    }
};
window.downloadFile = (base64Data, fileName) => {
    const link = document.createElement('a');
    link.href = base64Data;
    link.download = fileName;
    link.click();
};
<script>
    function openOutlookWebClient(mailtoLink) {
        window.open(mailtoLink, '_blank');
    }
</script>

