﻿namespace Blazor.Pages
{
    public class Mitarbeiter1
    {
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;

        public Mitarbeiter1() { }
    }
}
